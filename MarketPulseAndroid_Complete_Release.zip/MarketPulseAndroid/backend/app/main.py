from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timezone
from app.providers.yahoo import YahooFinanceProvider

app = FastAPI(title="MarketPulse API", version="1.0.0", description="Personal market research prototype; unofficial delayed data.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
provider = YahooFinanceProvider()
ALLOWED = {"NIFTY50", "SENSEX"}
INTERVALS = {"1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "60m", "1d": "1d"}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "marketpulse-api", "provider": provider.name}

@app.get("/v1/status")
async def status():
    return {"provider": provider.name, "market_data_configured": True,
            "data_classification": "UNOFFICIAL_DELAYED_OR_UNVERIFIED",
            "options_chain_configured": False,
            "message": "Unofficial Yahoo Finance data. Delay, coverage and rate limits are not guaranteed. Not for live trading."}

@app.get("/v1/quote/{symbol}")
async def quote(symbol: str):
    symbol = symbol.upper()
    if symbol not in ALLOWED: raise HTTPException(404, "Supported symbols: NIFTY50, SENSEX")
    return (await provider.get_quote(symbol)).model_dump()

@app.get("/v1/candles/{symbol}")
async def candles(symbol: str, interval: str = Query("5m"), period: str = Query("5d")):
    symbol = symbol.upper()
    if symbol not in ALLOWED: raise HTTPException(404, "Unsupported symbol")
    if interval not in INTERVALS: raise HTTPException(400, "Unsupported interval")
    data = await provider.get_candles(symbol, INTERVALS[interval], period)
    return {"symbol": symbol, "interval": interval, "source": provider.name,
            "freshness": "HISTORICAL_OR_DELAYED" if data else "UNAVAILABLE", "candles": data}

@app.get("/v1/analysis/{symbol}")
async def analysis(symbol: str, interval: str = Query("5m")):
    symbol = symbol.upper()
    if symbol not in ALLOWED: raise HTTPException(404, "Unsupported symbol")
    rows = await provider.get_candles(symbol, INTERVALS.get(interval, "5m"), "5d")
    if len(rows) < 30:
        return {"symbol": symbol, "signal": "NO TRADE", "confidence": None,
                "market_strength": "UNKNOWN", "reason": "Insufficient verified candles", "experimental": True}
    closes = [r["close"] for r in rows]
    e9 = sum(closes[-9:]) / 9
    e21 = sum(closes[-21:]) / 21
    changes = [closes[i] - closes[i-1] for i in range(1, len(closes))]
    gains = sum(max(x, 0) for x in changes[-14:]) / 14
    losses = sum(max(-x, 0) for x in changes[-14:]) / 14
    rsi = 100 if losses == 0 else 100 - (100 / (1 + gains / losses))
    momentum = (closes[-1] - closes[-6]) / closes[-6] * 100 if closes[-6] else 0
    if e9 > e21 and momentum > 0.03 and rsi < 75: signal = "UP"
    elif e9 < e21 and momentum < -0.03 and rsi > 25: signal = "DOWN"
    else: signal = "SIDEWAYS"
    strength = "STRONG" if abs(momentum) >= 0.15 else "MODERATE" if abs(momentum) >= 0.05 else "WEAK"
    confidence = min(0.70, 0.50 + abs(momentum) * 0.5)
    return {"symbol": symbol, "signal": signal, "confidence": round(confidence, 3),
            "market_strength": strength, "rsi14": round(rsi, 2), "ema9": round(e9, 2),
            "ema21": round(e21, 2), "momentum_pct": round(momentum, 4),
            "reason": "Experimental rule-based trend snapshot; not a validated probability or trading signal.",
            "experimental": True}

@app.get("/v1/options/{symbol}")
async def options(symbol: str):
    symbol = symbol.upper()
    if symbol not in ALLOWED: raise HTTPException(404, "Unsupported symbol")
    return {"symbol": symbol, "available": False, "provider": None, "expiries": [], "contracts": [],
            "message": "A verified authorised options-chain feed is not configured. No OI, IV, Greeks, PCR or max-pain values are fabricated."}
