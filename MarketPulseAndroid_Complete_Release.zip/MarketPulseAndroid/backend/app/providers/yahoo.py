"""Unofficial Yahoo Finance adapter. No guaranteed freshness, coverage or SLA."""
import asyncio
import yfinance as yf
from .base import MarketDataProvider, Quote

TICKERS = {"NIFTY50": "^NSEI", "SENSEX": "^BSESN"}

class YahooFinanceProvider(MarketDataProvider):
    name = "yahoo-finance-unofficial"

    async def _history(self, symbol: str, interval: str, period: str):
        ticker = TICKERS[symbol]
        return await asyncio.to_thread(lambda: yf.Ticker(ticker).history(period=period, interval=interval, auto_adjust=False))

    async def get_quote(self, symbol: str) -> Quote:
        try:
            frame = await self._history(symbol, "5m", "5d")
            if frame is None or frame.empty:
                return Quote(symbol=symbol, freshness="UNAVAILABLE", source=self.name)
            last = frame.iloc[-1]
            ltp = float(last["Close"])
            # Previous session close is preferable; use latest available daily close when present.
            daily = await self._history(symbol, "1d", "5d")
            prev = float(daily["Close"].iloc[-2]) if daily is not None and len(daily) >= 2 else ltp
            stamp = frame.index[-1]
            if getattr(stamp, "tzinfo", None) is None: stamp = stamp.tz_localize("Asia/Kolkata")
            return Quote(symbol=symbol, ltp=ltp, change=ltp-prev,
                         change_percent=((ltp-prev)/prev*100) if prev else None,
                         as_of=stamp.to_pydatetime().isoformat(), freshness="DELAYED", source=self.name)
        except Exception:
            return Quote(symbol=symbol, freshness="UNAVAILABLE", source=self.name)

    async def get_candles(self, symbol: str, interval: str, period: str):
        try:
            frame = await self._history(symbol, interval, period)
            if frame is None or frame.empty: return []
            frame = frame.dropna(subset=["Open", "High", "Low", "Close"])
            out = []
            for stamp, row in frame.tail(500).iterrows():
                ts = stamp
                if getattr(ts, "tzinfo", None) is None: ts = ts.tz_localize("Asia/Kolkata")
                out.append({"time": ts.isoformat(), "open": float(row["Open"]), "high": float(row["High"]),
                            "low": float(row["Low"]), "close": float(row["Close"]),
                            "volume": int(row["Volume"]) if row["Volume"] == row["Volume"] else 0})
            return out
        except Exception:
            return []
