package com.marketpulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Mint = Color(0xFF27C69A)
private val Red = Color(0xFFFF667A)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("marketpulse", MODE_PRIVATE)
        setContent { MarketPulseApp(prefs.getString("api", "") ?: "", { prefs.edit().putString("api", it).apply() }) }
    }
}

data class Candle(val time: String, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Long)
data class QuoteData(val ltp: Double?, val change: Double?, val pct: Double?, val freshness: String, val source: String, val asOf: String)

private suspend fun getJson(base: String, path: String): JSONObject = withContext(Dispatchers.IO) {
    val clean = base.trim().trimEnd('/')
    require(clean.startsWith("https://") || clean.startsWith("http://")) { "Enter your backend URL in Settings." }
    val conn = (URL(clean + path).openConnection() as HttpURLConnection)
    conn.connectTimeout = 12000; conn.readTimeout = 15000; conn.requestMethod = "GET"
    try {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("API error $code: $body")
        JSONObject(body)
    } finally { conn.disconnect() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketPulseApp(initialApi: String, saveApi: (String) -> Unit) {
    var api by remember { mutableStateOf(initialApi) }
    var symbol by remember { mutableStateOf("NIFTY50") }
    var tab by remember { mutableStateOf("Market") }
    var interval by remember { mutableStateOf("5m") }
    var quote by remember { mutableStateOf<QuoteData?>(null) }
    var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var analysis by remember { mutableStateOf<JSONObject?>(null) }
    var options by remember { mutableStateOf<JSONObject?>(null) }
    var status by remember { mutableStateOf("Backend not configured") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var cash by remember { mutableDoubleStateOf(100000.0) }
    var positions by remember { mutableStateOf(listOf<String>()) }
    val scope = rememberCoroutineScope()
    val symbolName = if (symbol == "NIFTY50") "NIFTY 50" else "SENSEX"

    fun refresh() {
        if (api.isBlank()) { error = "Open Settings and enter your deployed backend URL."; tab = "Settings"; return }
        scope.launch {
            busy = true; error = ""
            try {
                val q = getJson(api, "/v1/quote/$symbol")
                quote = QuoteData(q.optNullableDouble("ltp"), q.optNullableDouble("change"), q.optNullableDouble("change_percent"), q.optString("freshness", "UNKNOWN"), q.optString("source", ""), q.optString("as_of", ""))
                val c = getJson(api, "/v1/candles/$symbol?interval=$interval")
                val arr = c.optJSONArray("candles") ?: JSONArray()
                candles = (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Candle(it.optString("time"), it.optDouble("open"), it.optDouble("high"), it.optDouble("low"), it.optDouble("close"), it.optLong("volume")) } }
                analysis = getJson(api, "/v1/analysis/$symbol?interval=$interval")
                status = "Connected · ${quote?.freshness ?: "UNKNOWN"}"
            } catch (e: Exception) { error = e.message ?: "Could not reach backend"; status = "Connection unavailable" }
            finally { busy = false }
        }
    }
    fun loadOptions() {
        if (api.isBlank()) { error = "Configure the backend URL in Settings first."; return }
        scope.launch { busy = true; try { options = getJson(api, "/v1/options/$symbol") } catch (e: Exception) { error = e.message ?: "Options request failed" } finally { busy = false } }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Navy, surface = Panel, onSurface = Color.White)) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(title = { Column { Text("MarketPulse", fontWeight = FontWeight.Bold); Text(status, fontSize = 11.sp, color = Muted) } },
                actions = { TextButton(onClick = { refresh() }) { Text("REFRESH") } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White))
        }, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Market", "Charts", "Options", "AI", "Paper", "Settings").forEach { name ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name; if (name == "Options") loadOptions() }, icon = { Text(when(name){"Market"->"⌂";"Charts"->"▥";"Options"->"⇄";"AI"->"✦";"Paper"->"₹";else->"⚙"}) }, label = { Text(name, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("NIFTY50" to "NIFTY 50", "SENSEX" to "SENSEX").forEach { (key, label) ->
                            FilterChip(selected = symbol == key, onClick = { symbol = key; quote = null; candles = emptyList(); analysis = null; refresh() }, label = { Text(label) })
                        }
                    }
                }
                if (error.isNotBlank()) item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF492A36))) { Text(error, Modifier.padding(12.dp), color = Color.White) } }
                when (tab) {
                    "Market" -> {
                        item { QuoteCard(symbolName, quote, busy, ::refresh) }
                        item { SectionTitle("Market snapshot") }
                        item { Text("Data is unofficial and may be delayed. Verify prices independently before making decisions.", color = Muted, fontSize = 12.sp) }
                        item { SectionTitle("Quick analysis") }
                        item { AnalysisCard(analysis) }
                        item { SectionTitle("Market data") }
                        item { Text("Source: ${quote?.source ?: "Not connected"}\nLast source timestamp: ${quote?.asOf ?: "—"}", color = Muted, fontSize = 12.sp) }
                    }
                    "Charts" -> {
                        item { SectionTitle("${symbolName} · Candlestick chart") }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("1m", "5m", "15m", "30m", "1h", "1d").forEach { FilterChip(selected = interval == it, onClick = { interval = it; refresh() }, label = { Text(it) }) } } }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(12.dp)) { if (candles.isNotEmpty()) CandleChart(candles) else Text("No candle data yet. Configure the backend and tap Refresh.", color = Muted, modifier = Modifier.padding(12.dp)); Text("${candles.size} candles · ${quote?.freshness ?: "No data"}", color = Muted, fontSize = 11.sp) } } }
                        item { SectionTitle("Technical indicators") }
                        item { IndicatorList(candles) }
                        item { Text("EMA, RSI, MACD, VWAP and ATR are calculated from available candles. Indicator values are analytical tools, not forecasts.", color = Muted, fontSize = 12.sp) }
                    }
                    "Options" -> {
                        item { SectionTitle("${symbolName} · Options chain") }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("CALL (CE)        STRIKE        PUT (PE)", fontWeight = FontWeight.Bold)
                            Text("Expiry, LTP, OI, change in OI, volume, IV and Greeks", color = Muted, fontSize = 12.sp)
                            Divider(color = Muted.copy(alpha = .3f))
                            Text(options?.optString("message") ?: "Checking options-chain availability…", color = Color.White)
                            Text("No synthetic or fabricated option contracts are displayed.", color = Mint, fontSize = 12.sp)
                            OutlinedButton(onClick = { loadOptions() }) { Text("CHECK DATA AGAIN") }
                        } } }
                        item { SectionTitle("Options analytics") }
                        item { Text("PCR, max pain and Greeks will be enabled only when a verified options-chain feed is connected.", color = Muted) }
                    }
                    "AI" -> {
                        item { SectionTitle("AI market view · ${symbolName}") }
                        item { AnalysisCard(analysis) }
                        item { Text("This release uses an experimental rule-based snapshot, not a trained or validated predictive model. Confidence is not a calibrated probability of the next candle.", color = Muted, fontSize = 12.sp) }
                        item { OutlinedButton(onClick = { refresh() }) { Text("UPDATE ANALYSIS") } }
                    }
                    "Paper" -> {
                        item { SectionTitle("Paper trading") }
                        item { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp)) { Text("Virtual balance", color = Muted); Text("₹${cash.fmt()}", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("No real orders are sent.", color = Mint, fontSize = 12.sp) } } }
                        item { Text("Simulated market entry uses the latest available index quote. This is a learning ledger, not an executable options simulator.", color = Muted, fontSize = 12.sp) }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { val p = quote?.ltp; if (p != null && cash >= p) { cash -= p; positions = positions + "BUY $symbolName @ ₹${p.fmt()}" } else error = "Refresh a valid quote first." }) { Text("SIMULATE BUY 1") }
                            OutlinedButton(onClick = { val p = quote?.ltp; if (p != null && positions.isNotEmpty()) { cash += p; positions = positions + "SELL $symbolName @ ₹${p.fmt()}" } else error = "No simulated position or quote." }) { Text("SIMULATE SELL") }
                        } }
                        item { SectionTitle("Activity") }
                        if (positions.isEmpty()) item { Text("No paper trades yet.", color = Muted) }
                        items(positions.reversed()) { Text(it, color = Color.White, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(8.dp)).padding(10.dp)) }
                    }
                    else -> {
                        item { SectionTitle("Backend settings") }
                        item { Text("Deploy the included FastAPI backend first, then paste its HTTPS URL below. Do not put broker passwords or API secrets here.", color = Muted, fontSize = 12.sp) }
                        item { OutlinedTextField(value = api, onValueChange = { api = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Backend base URL") }, placeholder = { Text("https://your-service.example.com") }, singleLine = true) }
                        item { Button(onClick = { saveApi(api); error = "Backend URL saved. Tap Refresh."; tab = "Market" }) { Text("SAVE BACKEND URL") } }
                        item { OutlinedButton(onClick = { refresh() }) { Text("TEST CONNECTION / REFRESH") } }
                        item { Text("The Yahoo Finance connector is unofficial; uptime, data delay and API limits are not guaranteed. The options-chain endpoint intentionally reports unavailable until a suitable provider is configured.", color = Muted, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable private fun SectionTitle(text: String) { Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White) }
@Composable private fun QuoteCard(name: String, q: QuoteData?, busy: Boolean, refresh: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(name, color = Muted); Text(q?.ltp?.let { "₹${it.fmt()}" } ?: "—", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        val ch = q?.change; val pct = q?.pct
        Text(if (ch != null && pct != null) "${if (ch >= 0) "+" else ""}${ch.fmt()} (${pct.fmt()}%)" else "Price unavailable", color = if ((ch ?: 0.0) >= 0) Mint else Red)
        Text("${q?.freshness ?: "DATA NOT CONNECTED"} · ${q?.asOf ?: "No timestamp"}", color = Muted, fontSize = 11.sp)
        Button(onClick = refresh, enabled = !busy) { Text(if (busy) "LOADING…" else "REFRESH DATA") }
    } }
}
@Composable private fun AnalysisCard(a: JSONObject?) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(a?.optString("signal") ?: "NO DATA", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Mint)
        Text("Strength: ${a?.optString("market_strength") ?: "UNKNOWN"} · Confidence estimate: ${a?.optNullableDouble("confidence")?.let { "${(it*100).toInt()}%" } ?: "—"}", color = Muted)
        Text(a?.optString("reason") ?: "Connect backend and retrieve enough candles to calculate the snapshot.", color = Color.White, fontSize = 12.sp)
        if (a?.optBoolean("experimental") == true) Text("EXPERIMENTAL — NOT A TRADING SIGNAL", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    } }
}
@Composable private fun IndicatorList(rows: List<Candle>) {
    val closes = rows.map { it.close }
    fun ema(values: List<Double>, period: Int): Double? {
        if (values.size < period) return null
        val alpha = 2.0 / (period + 1.0)
        return values.drop(period).fold(values.take(period).average()) { acc, value -> alpha * value + (1-alpha) * acc }
    }
    val ema9 = ema(closes, 9)
    val ema21 = ema(closes, 21)
    val ema12 = ema(closes, 12)
    val ema26 = ema(closes, 26)
    val macd = if (ema12 != null && ema26 != null) ema12 - ema26 else null
    val deltas = closes.zipWithNext { a,b -> b-a }.takeLast(14)
    val avgGain = deltas.map { it.coerceAtLeast(0.0) }.average()
    val avgLoss = deltas.map { (-it).coerceAtLeast(0.0) }.average()
    val rsi = if (deltas.size < 14) null else if (avgLoss == 0.0) 100.0 else 100.0 - 100.0/(1.0+avgGain/avgLoss)
    val typical = rows.map { (it.high + it.low + it.close) / 3.0 }
    val totalVol = rows.sumOf { it.volume.coerceAtLeast(0) }
    val vwap = if (totalVol > 0) rows.indices.sumOf { i -> typical[i] * rows[i].volume.coerceAtLeast(0) } / totalVol else null
    val tr = rows.zipWithNext().map { (prev, cur) -> maxOf(cur.high-cur.low, kotlin.math.abs(cur.high-prev.close), kotlin.math.abs(cur.low-prev.close)) }.takeLast(14)
    val atr = if (tr.size == 14) tr.average() else null
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("EMA 9" to ema9, "EMA 21" to ema21, "RSI 14" to rsi, "MACD (12,26)" to macd, "VWAP" to vwap, "ATR 14" to atr).forEach { (n,v) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(n); Text(v?.fmt() ?: "Insufficient data", color = if (v == null) Muted else Mint) }
        }
    } }
}
@Composable private fun CandleChart(rows: List<Candle>) {
    val data = rows.takeLast(70)
    Canvas(Modifier.fillMaxWidth().height(240.dp).background(Panel)) {
        if (data.isEmpty()) return@Canvas
        val minP = data.minOf { it.low }; val maxP = data.maxOf { it.high }; val range = (maxP-minP).takeIf { it > 0 } ?: 1.0
        val step = size.width / data.size; val body = (step * .58f).coerceAtLeast(2f)
        data.forEachIndexed { i,c ->
            val x = step*i + step/2
            fun y(p: Double) = size.height - (((p-minP)/range).toFloat()*size.height)
            val color = if (c.close >= c.open) Mint else Red
            drawLine(color, Offset(x,y(c.high)), Offset(x,y(c.low)), strokeWidth = 1.5f)
            val top = y(maxOf(c.open,c.close)); val bottom = y(minOf(c.open,c.close))
            drawRect(color, Offset(x-body/2, top), androidx.compose.ui.geometry.Size(body, (bottom-top).coerceAtLeast(2f)))
        }
    }
}
private fun JSONObject.optNullableDouble(key: String): Double? = if (isNull(key) || !has(key)) null else optDouble(key).takeIf { it.isFinite() }
private fun Double.fmt(): String = String.format(Locale.US, "%,.2f", this)
