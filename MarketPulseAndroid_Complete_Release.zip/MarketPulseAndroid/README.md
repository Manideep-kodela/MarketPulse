# MarketPulse — integrated Android + API prototype

This is a personal market-research and paper-trading prototype for NIFTY 50 and SENSEX. It is **not** a broker terminal and does not place real orders.

## Included
- Android app (Jetpack Compose) with Market, Charts, Options, AI, Paper and Settings tabs.
- NIFTY 50 (`^NSEI`) and SENSEX (`^BSESN`) quote/candle adapter using the unofficial `yfinance` library.
- Candlestick chart and locally calculated EMA 9/21, RSI 14, MACD line, VWAP and ATR 14 when candle data is available.
- Experimental, rule-based trend snapshot. It is not a trained model, a calibrated probability, or a validated trading signal.
- Paper-trading learning ledger (local in-app virtual balance; simplified index-unit simulation, not an options execution simulator).
- Options-chain screen and API contract. The API deliberately returns `available: false` until a suitable authorised options feed is configured. No contracts/OI/IV/Greeks/PCR/max-pain are fabricated.

## Important data limitations
Yahoo Finance access through `yfinance` is unofficial. It has no guaranteed API, freshness, latency, uptime, completeness or rate limit. Data may be delayed, stale, missing or blocked. The app labels the feed as delayed/unverified and must not be used as the sole basis for trades. A free index-quote source does not imply access to a complete NIFTY/SENSEX options chain. To enable genuine option-chain data, integrate a provider whose licence explicitly permits your intended use.

## Backend deployment
The API is in `backend/` and has a Dockerfile. The included `render.yaml` is a starting point for a Render Docker web service. Free services may sleep when idle and can have ephemeral storage/limited resources. After deployment, copy the service HTTPS URL into the app under Settings → Backend base URL, save it, then refresh.

Endpoints:
- `GET /health`
- `GET /v1/status`
- `GET /v1/quote/NIFTY50` or `/v1/quote/SENSEX`
- `GET /v1/candles/NIFTY50?interval=5m`
- `GET /v1/analysis/NIFTY50?interval=5m`
- `GET /v1/options/NIFTY50` (honestly reports unavailable until configured)

Run locally: `cd backend && pip install -r requirements.txt && uvicorn app.main:app --reload --host 0.0.0.0 --port 8000`.

## Android build
Open `android/` in Android Studio, or use the GitHub Actions workflow supplied separately in `github-workflow-android.yml`. The debug APK is for testing. A production release should use a securely managed signing key and a release build.

## Safety / scope
No real orders, broker login, API keys or secrets are required by this prototype. Predictions are experimental. Paper trading is simplified and excludes fees, slippage, taxes, lot sizes and exchange execution rules. Do not use the output as investment advice.
