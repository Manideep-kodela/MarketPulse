package com.marketpulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarketPulseScreen() }
    }
}

@Composable
private fun MarketPulseScreen() {
    var selected by remember { mutableStateOf("NIFTY 50") }
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("MarketPulse") }) }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Text("Indian market dashboard", style = MaterialTheme.typography.titleLarge) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected == "NIFTY 50", { selected = "NIFTY 50" }, label = { Text("NIFTY 50") })
                        FilterChip(selected == "SENSEX", { selected = "SENSEX" }, label = { Text("SENSEX") })
                    }
                }
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(selected, style = MaterialTheme.typography.titleMedium)
                            Text("--", style = MaterialTheme.typography.headlineLarge)
                            Text("Price unavailable — data provider not configured")
                            AssistChip(onClick = {}, label = { Text("DATA NOT CONNECTED") })
                        }
                    }
                }
                item { Text("Chart & indicators", style = MaterialTheme.typography.titleMedium) }
                item { Text("Candlesticks · EMA · RSI · MACD · VWAP · ATR") }
                item { Text("AI market view", style = MaterialTheme.typography.titleMedium) }
                item { Text("UP / DOWN / SIDEWAYS / NO TRADE will appear only after validated market data is connected.") }
                item { Text("Paper trading only", style = MaterialTheme.typography.titleMedium) }
                item { Text("No real orders are placed by this app.") }
            }
        }
    }
}
