# MarketPulse — NIFTY 50 & SENSEX Android starter

This is the initial project scaffold for an Android market-analysis and paper-trading app.

## Important data status
- No exchange-authorised free public tick-by-tick feed for embedding in a third-party app has been established.
- NSE's public AI/MCP data service describes intraday data as approximately 1–3 minutes delayed and says it is for information/learning, not real-time trading or commercial products. It is not a general-purpose mobile-app streaming API.
- NSE's official market-data page describes real-time feed products as subscription products / authorised-vendor access.
- ICICI Direct Breeze advertises API access without an additional API fee, including historical data and streaming OHLC; access is tied to its service/account and applicable terms. It is a candidate for a later integration, not yet connected.
- Therefore the app must never label an unverified source as LIVE. Until a compliant provider is configured, the app reports `DATA_SOURCE_NOT_CONFIGURED` and does not fabricate prices.

## Architecture
- `android/`: Kotlin Android app shell (Jetpack Compose).
- `backend/`: FastAPI service and replaceable market-data provider interface.
- `docs/`: implementation plan and data-source notes.

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/health and http://127.0.0.1:8000/docs.

## Android build
Open `android/` in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). A working Android SDK/Gradle installation is required. This environment did not have Android SDK/Gradle configured, so no installable APK is included yet.

## First milestone
1. Android dashboard and instrument selection.
2. Backend health/status + provider abstraction.
3. Connect a legally usable free/delayed source and clearly label freshness.
4. Candles and indicators.
5. Model inference and paper trading only after data validation.
