from .base import MarketDataProvider, Quote

class UnconfiguredProvider(MarketDataProvider):
    name = "not-configured"

    async def get_quote(self, symbol: str) -> Quote:
        # Deliberately no synthetic/fake market prices.
        return Quote(symbol=symbol, freshness="UNAVAILABLE", source=self.name)
