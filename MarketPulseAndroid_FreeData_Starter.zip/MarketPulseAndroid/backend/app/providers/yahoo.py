"""Unofficial Yahoo Finance adapter for personal/educational prototyping.

Yahoo Finance does not provide a supported public API or guaranteed delay/SLA.
Treat returned timestamps as source timestamps and never call this LIVE.
"""
import asyncio
from datetime import datetime, timezone

import yfinance as yf

from .base import MarketDataProvider, Quote

TICKERS = {
    "NIFTY50": "^NSEI",
    "SENSEX": "^BSESN",
}


class YahooFinanceProvider(MarketDataProvider):
    name = "yahoo-finance-unofficial"

    async def get_quote(self, symbol: str) -> Quote:
        ticker = TICKERS[symbol]
        try:
            frame = await asyncio.to_thread(
                lambda: yf.Ticker(ticker).history(period="5d", interval="5m", auto_adjust=False)
            )
            if frame is None or frame.empty:
                return Quote(
                    symbol=symbol,
                    freshness="UNAVAILABLE",
                    source=self.name,
                )

            latest = frame.iloc[-1]
            ltp = float(latest["Close"])
            previous = frame.iloc[-2] if len(frame.index) > 1 else latest
            previous_close = float(previous["Close"])
            change = ltp - previous_close
            change_percent = (change / previous_close * 100.0) if previous_close else None
            stamp = frame.index[-1]
            if getattr(stamp, "tzinfo", None) is None:
                stamp = stamp.tz_localize("Asia/Kolkata")
            as_of = stamp.to_pydatetime().isoformat()

            return Quote(
                symbol=symbol,
                ltp=ltp,
                change=change,
                change_percent=change_percent,
                as_of=as_of,
                freshness="DELAYED",
                source=self.name,
            )
        except Exception:
            # Do not fabricate prices or leak upstream exception details to clients.
            return Quote(symbol=symbol, freshness="UNAVAILABLE", source=self.name)
