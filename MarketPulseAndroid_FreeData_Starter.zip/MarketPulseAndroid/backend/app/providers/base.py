from abc import ABC, abstractmethod
from typing import Literal
from pydantic import BaseModel

class Quote(BaseModel):
    symbol: str
    ltp: float | None = None
    change: float | None = None
    change_percent: float | None = None
    as_of: str | None = None
    freshness: Literal["LIVE", "DELAYED", "HISTORICAL", "STALE", "UNAVAILABLE"]
    source: str

class MarketDataProvider(ABC):
    name: str

    @abstractmethod
    async def get_quote(self, symbol: str) -> Quote:
        raise NotImplementedError
