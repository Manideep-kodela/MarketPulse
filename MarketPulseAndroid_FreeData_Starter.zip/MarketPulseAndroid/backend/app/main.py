from fastapi import FastAPI, HTTPException
from app.providers.yahoo import YahooFinanceProvider

app = FastAPI(title="MarketPulse API", version="0.2.0")
provider = YahooFinanceProvider()
ALLOWED = {"NIFTY50", "SENSEX"}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "marketpulse-api", "provider": provider.name}

@app.get("/v1/quote/{symbol}")
async def quote(symbol: str):
    symbol = symbol.upper()
    if symbol not in ALLOWED:
        raise HTTPException(status_code=404, detail="Supported symbols: NIFTY50, SENSEX")
    result = await provider.get_quote(symbol)
    return result.model_dump()

@app.get("/v1/status")
async def status():
    return {
        "provider": provider.name,
        "market_data_configured": True,
        "data_classification": "DELAYED_OR_UNVERIFIED",
        "message": "Unofficial Yahoo Finance data. Delay, availability and rate limits are not guaranteed. Not for live trading.",
    }
