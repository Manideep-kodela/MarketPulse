# MarketPulse backend

Install dependencies and run locally:

```bash
python -m pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Endpoints:
- `GET /health`
- `GET /v1/status`
- `GET /v1/quote/NIFTY50`
- `GET /v1/quote/SENSEX`

The Yahoo Finance connector is unofficial. It may return unavailable data or
be rate-limited. Quotes are always labelled `DELAYED`, not `LIVE`.
