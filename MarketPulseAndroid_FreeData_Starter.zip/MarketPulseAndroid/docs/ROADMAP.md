# Implementation roadmap

## Phase 1 — app foundation (scaffolded)
- Android Compose app shell, NIFTY/SENSEX selector, explicit disconnected-data state.
- FastAPI health, status, quote routes and provider interface.

## Phase 2 — data connector
- Evaluate ICICI Breeze eligibility and API terms for personal display in this app.
- Confirm NIFTY 50 and SENSEX index support, live/delayed classification, historical candle interval, request limits, and display/storage rights.
- Implement adapter only after these are verified. Keep API credentials on backend, never in the APK.

## Phase 3 — charts and indicators
- OHLC candle API; 1m/5m/15m/1h/1D views where provider supports them.
- EMA, RSI, MACD, VWAP, ATR; mark missing/partial candles.

## Phase 4 — analysis
- Market regime and next-candle probabilities with confidence and abstain/NO TRADE state.
- Walk-forward validation, out-of-sample reporting, transaction-cost and slippage assumptions.
- Never market an unvalidated probability as a guaranteed forecast.

## Phase 5 — paper trading and alerts
- Virtual positions, P&L, stop-loss/target simulation, alert preferences, notification permissions.
- No broker order placement in initial release.
