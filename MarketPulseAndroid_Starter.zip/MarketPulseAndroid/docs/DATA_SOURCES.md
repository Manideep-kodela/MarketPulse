# Data-source assessment (initial)

| Candidate | Cost/access | Freshness/limitations | Decision |
|---|---|---|---|
| NSE public MCP service | Publicly described as free; designed for AI assistants | NSE says intraday data is about 1–3 minutes delayed, no tick/order-book feed, and not intended for real-time trading or commercial products | Useful for manual research; not selected as app backend feed |
| NSE official market-data products | Paid / subscription or authorised-vendor route | Official real-time products include level feeds and snapshot feeds | Correct route if production-grade live feed is later required |
| ICICI Direct Breeze | Advertises no additional API charge | Account/service access and API terms apply; validate exact NIFTY/SENSEX instruments, rate limits and display rights before use | Best candidate to test for a no-extra-API-fee approach, subject to eligibility |
| Unofficial NSE website endpoints / scraping | No formal API fee | Unstable, may be rate-limited or blocked; terms and redistribution rights are uncertain | Do not build production dependency on this |

A zero-API-fee provider is not automatically a zero-cost, unrestricted, exchange-licensed data feed. Before displaying data to other users or publishing the app, obtain written clarity on display, storage, redistribution, and commercial-use permissions.
