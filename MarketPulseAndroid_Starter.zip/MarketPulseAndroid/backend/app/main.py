from fastapi import FastAPI, HTTPException
from app.providers.unconfigured import UnconfiguredProvider

app = FastAPI(title="MarketPulse API", version="0.1.0")
provider = UnconfiguredProvider()
ALLOWED = {"NIFTY50", "SENSEX"}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "marketpulse-api", "provider": provider.name}

@app.get("/v1/quote/{symbol}")
async def quote(symbol: str):
    symbol = symbol.upper()
    if symbol not in ALLOWED:
        raise HTTPException(status_code=404, detail="Supported symbols: NIFTY50, SENSEX")
    result = await provider.get_quote(symbol)
    return result.model_dump()

@app.get("/v1/status")
async def status():
    return {
        "provider": provider.name,
        "market_data_configured": False,
        "message": "No verified data provider configured. No prices are being fabricated."
    }
